import type {
  FeedCounts,
  UserNotification,
} from "../composables/notification/useNotifications";
import type { RealtimeEvent } from "#dms-core/app/composables/realtime/useUserRealtime";
import { isObject, isString } from "#dms-core/app/utils/type-check";

const NOTIFICATION_TOPIC_PREFIX = "notifications:user:";
const NOTIFICATION_NEW_TYPE = "notification:new";
const NOTIFICATION_READ_TYPE = "notification:read";
const NOTIFICATION_ALL_READ_TYPE = "notification:all-read";
const NOTIFICATION_UNREAD_TYPE = "notification:unread";

interface IncomingPayload {
  notification?: UserNotification;
  ids?: string[];
  /** The whole feed's counts after a read state change. */
  counts?: FeedCounts;
}

const isNotificationEvent = (
  event: unknown,
): event is { type: string; payload?: IncomingPayload } =>
  !!event && isObject(event) && isString(event.type);

type Handler = (payload: IncomingPayload | undefined) => void | Promise<void>;

export default defineDmsPlugin(() => {
  const { user, loggedIn } = useDmsUserSession();
  const {
    handleIncomingNotification,
    handleRemoteRead,
    handleRemoteUnread,
    handleRemoteAllRead,
  } = useNotifications();
  const realtime = useUserRealtime();

  const handlers: Record<RealtimeEvent["type"], Handler> = {
    [NOTIFICATION_NEW_TYPE]: (payload) => {
      if (payload?.notification)
        handleIncomingNotification(payload.notification);
    },
    [NOTIFICATION_READ_TYPE]: async (payload) => {
      if (Array.isArray(payload?.ids))
        await handleRemoteRead(payload.ids, payload.counts);
    },
    [NOTIFICATION_UNREAD_TYPE]: async (payload) => {
      if (Array.isArray(payload?.ids))
        await handleRemoteUnread(payload.ids, payload.counts);
    },
    [NOTIFICATION_ALL_READ_TYPE]: async (payload) => {
      await handleRemoteAllRead(payload?.counts);
    },
  };

  let unsubscribe: (() => void) | undefined;

  watch(
    () => (loggedIn.value ? user.value?._id : undefined),
    (userId) => {
      unsubscribe?.();
      unsubscribe = undefined;
      if (!userId) return;
      unsubscribe = realtime.subscribe(
        `${NOTIFICATION_TOPIC_PREFIX}${userId}`,
        (event) => {
          if (!isNotificationEvent(event)) return;
          const handler = handlers[event.type];
          if (!handler) return;
          void handler(event.payload);
        },
      );
    },
    { immediate: true },
  );
});
